<?php

namespace PhpOffice\PhpPresentation\Slide;

class AbstractBackground
{

}
